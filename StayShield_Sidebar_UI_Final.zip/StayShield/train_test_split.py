"""Reproducible stratified train/test split."""
from sklearn.model_selection import train_test_split
from config import TARGET, RANDOM_STATE
from preprocessing import engineer_features

def split_data(df, test_size=0.2, split_method='stratified', random_state=RANDOM_STATE):
    data = engineer_features(df).copy(); y = data.pop(TARGET)
    data = data.drop(columns=['reservation_status','reservation_status_date'], errors='ignore')
    return train_test_split(data, y, test_size=test_size, random_state=random_state, stratify=y)
