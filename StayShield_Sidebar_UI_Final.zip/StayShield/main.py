"""Command-line training and analysis entry point."""
from load_data import load_raw
from model_training import train_models
from preprocessing import get_preprocessing_report

def main():
    df=load_raw(); print(f'StayShield dataset: {len(df):,} rows x {len(df.columns)} columns')
    print('Preprocessing report:',get_preprocessing_report(df))
    print('\nTraining classifiers...')
    for row in train_models(df): print(row)
if __name__=='__main__': main()
