# StayShield — Hotel Booking Cancellation Prediction

Flask machine-learning project rebuilt from the supplied PythonProject3 project. The same main page flow is retained: Dataset Overview, EDA, Preprocessing, Linear Regression baseline, Logistic Regression, Tree & Ensemble Models, Unsupervised Learning, Evaluation, and Train Models. Existing aliases for K-Means, Hierarchical, DBSCAN, PCA, anomaly detection, and evaluation routes are retained.

## Dataset required

Place the original `hotel_bookings.csv` in the project root, next to `app.py`. Expected source schema: 119,390 rows and 32 columns; target `is_canceled` (`0 = kept`, `1 = canceled`). The supplied hotel dataset is included as `hotel_bookings.csv` in this ZIP. The app gives a clear message until the real dataset is added.

The model deliberately excludes `reservation_status` and `reservation_status_date` because they leak the cancellation outcome. The dataset overview still displays source columns when the file is present.

## Run in PyCharm (Windows)

1. Extract the ZIP into a folder named `StayShield`.
2. Copy `hotel_bookings.csv` into the `StayShield` folder.
3. Open the folder in PyCharm and select Python 3.12 (recommended) or Python 3.11/3.13. Avoid Python versions without a scikit-learn wheel; otherwise pip may try to compile C/C++ sources.
4. Open the PyCharm Terminal and run:

   ```powershell
   python -m venv .venv
   .venv\Scripts\activate
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   python main.py
   ```

   `python main.py` trains the supervised models and writes `artifacts/models.joblib` and `artifacts/model_metrics.csv`.
5. Start the website:

   ```powershell
   python app.py
   ```

6. Open `http://127.0.0.1:5000` in your browser. If you skipped the training step, open **Train Models** and click **Train / Retrain Models**. The included old model artifact is intentionally omitted so models retrain under the pinned compatible scikit-learn version and avoid the `_loss` unpickling error.

## Algorithms and metrics

- Classification: Logistic Regression, Decision Tree, Random Forest, AdaBoost, Gradient Boosting, Bagging Classifier.
- Retained baseline: Linear Regression, adapted as a continuous score for a binary label; use Logistic Regression or the tree classifiers for actual class/probability predictions.
- Unsupervised: K-Means with elbow/silhouette diagnostics, Agglomerative/Hierarchical clustering, DBSCAN, PCA, Isolation Forest.
- Metrics for every classifier: accuracy, precision, recall, F1, ROC-AUC, confusion matrix, classification report, and training time. Linear Regression baseline: R², MAE, RMSE. Generated graphs: per-metric comparison bars, ROC curves, one confusion matrix per classifier, and actual-vs-predicted regression plot. The charts are regenerated each time models train.
- Preprocessing: numeric median imputation + StandardScaler; categorical most-frequent imputation + OneHotEncoder with unknown-category handling; stratified train/test split; preprocessing fitted only on training data.
- Feature engineering: `total_nights` and `total_guests` where source fields exist.
- Outlier tools: IQR fences and optional clipping; Min-Max/Standard scaling and one-hot/ordinal encoding utilities are retained as standalone modules.

To keep laptop runs manageable, supervised model training uses a deterministic stratified sample of up to 30,000 rows by default. Increase `sample_limit` in `model_training.py` if your machine has enough memory and time.

## Modules

`app.py`, `main.py`, `load_data.py`, `EDA.py`, `preprocessing.py`, `encoding.py`, `scaling.py`, `outlier_treatment.py`, `train_test_split.py`, `model_training.py`, `linear_regression.py`, `logistic_regression.py`, `tree_models.py`, `unsupervised.py`, `evaluation.py`, and `config.py` are maintained as separate modules. Templates retain the original page filenames and `static/css`, `static/js`, `static/charts` layout. Charts are generated from the booking dataset at runtime; no legacy-domain charts are reused.

## Tests

Run `python -m unittest discover -s scratch -v`. Tests exercise page routing and confirm leakage columns are excluded from model input. The actual hotel dataset is required for data-backed integration tests.
