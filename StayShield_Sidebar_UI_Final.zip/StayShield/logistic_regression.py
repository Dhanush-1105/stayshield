"""Logistic regression classification pipeline."""
from model_training import train_models
from config import ARTIFACT_DIR
import joblib

def get_logistic_regression_pipeline(df=None):
    if not (ARTIFACT_DIR/'models.joblib').exists(): train_models(df)
    return joblib.load(ARTIFACT_DIR/'models.joblib')['models']['Logistic Regression']
