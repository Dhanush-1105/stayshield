"""Evaluation metrics and model comparison utilities."""
import joblib, pandas as pd
from config import ARTIFACT_DIR
from model_training import train_models

def get_evaluation_suite(df=None):
    if not (ARTIFACT_DIR/'models.joblib').exists(): train_models(df)
    return joblib.load(ARTIFACT_DIR/'models.joblib')
