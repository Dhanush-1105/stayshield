"""Unsupervised analysis: K-Means, hierarchical clustering, DBSCAN, PCA and Isolation Forest."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.cluster import KMeans, DBSCAN, AgglomerativeClustering
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest
from sklearn.metrics import silhouette_score
from preprocessing import engineer_features

def get_unsupervised_suite(df):
    data=engineer_features(df).drop(columns=['is_canceled','reservation_status','reservation_status_date'],errors='ignore')
    num=data.select_dtypes(include='number'); num=num.replace([np.inf,-np.inf],np.nan)
    X=SimpleImputer(strategy='median').fit_transform(num)
    X=StandardScaler().fit_transform(X)
    rng=np.random.RandomState(42); X=X[rng.choice(len(X),min(2500,len(X)),replace=False)] if len(X)>2500 else X
    return {'X':X,'columns':num.columns.tolist()}

def run_kmeans(suite,k=3):
    X=suite['X']; ks=list(range(2,9)); inertia=[]; sil=[]
    for n in ks:
        m=KMeans(n_clusters=n,n_init=5,random_state=42).fit(X); inertia.append(float(m.inertia_)); sil.append(float(silhouette_score(X,m.labels_,sample_size=min(800,len(X)),random_state=42)))
    model=KMeans(n_clusters=int(k),n_init=5,random_state=42).fit(X); return {'k':int(k),'inertia':float(model.inertia_),'silhouette':float(silhouette_score(X,model.labels_,sample_size=min(800,len(X)),random_state=42)),'suggested_k':ks[int(np.argmax(sil))],'elbow':list(zip(ks,inertia,sil)),'counts':pd.Series(model.labels_).value_counts().sort_index().to_dict()}
def run_hierarchical(suite,k=3,linkage_method='ward'):
    X=suite['X'][:1200]; labels=AgglomerativeClustering(n_clusters=k,linkage=linkage_method).fit_predict(X)
    return {'k':k,'silhouette':float(silhouette_score(X,labels,sample_size=min(700,len(X)),random_state=42)),'counts':pd.Series(labels).value_counts().sort_index().to_dict()}
def run_dbscan(suite,eps=1.5,min_samples=15):
    X=suite['X']; labels=DBSCAN(eps=eps,min_samples=min_samples).fit_predict(X); n=len(set(labels)-{-1}); return {'n_clusters':n,'n_noise':int((labels==-1).sum()),'pct_noise':round(float((labels==-1).mean()*100),2),'eps':eps,'min_samples':min_samples}
def run_pca_view(suite):
    p=PCA(n_components=2,random_state=42); z=p.fit_transform(suite['X']); return {'pc1_pct':round(p.explained_variance_ratio_[0]*100,2),'pc2_pct':round(p.explained_variance_ratio_[1]*100,2),'total_2d_pct':round(p.explained_variance_ratio_.sum()*100,2),'loadings':pd.DataFrame(p.components_.T,columns=['PC1','PC2'],index=suite['columns']).round(3).to_dict('index')}
def run_isolation_forest(suite,contamination=.01):
    labels=IsolationForest(contamination=contamination,random_state=42,n_estimators=100).fit_predict(suite['X']); return {'outliers':int((labels==-1).sum()),'outlier_pct':round(float((labels==-1).mean()*100),2),'contamination':contamination}
def get_unsupervised_comparison_table(km_res,hier_res,db_res,pca_res,anomaly_res): return [{'algorithm':'K-Means','result':f"{km_res['k']} clusters; silhouette {km_res['silhouette']:.3f}"},{'algorithm':'Hierarchical','result':f"{hier_res['k']} clusters; silhouette {hier_res['silhouette']:.3f}"},{'algorithm':'DBSCAN','result':f"{db_res['n_clusters']} clusters; {db_res['pct_noise']}% noise"},{'algorithm':'PCA','result':f"2D variance retained {pca_res['total_2d_pct']}%"},{'algorithm':'Isolation Forest','result':f"{anomaly_res['outlier_pct']}% flagged as anomalies"}]
