"""Shared project configuration for StayShield."""
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "hotel_bookings.csv"
ARTIFACT_DIR = BASE_DIR / "artifacts"
CHART_DIR = BASE_DIR / "static" / "charts"
TARGET = "is_canceled"
LEAKAGE_COLUMNS = ["reservation_status", "reservation_status_date"]
RANDOM_STATE = 42
