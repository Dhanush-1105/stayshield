"""Leakage-safe tabular preprocessing for booking cancellation prediction."""
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from config import TARGET, LEAKAGE_COLUMNS

def engineer_features(df):
    out = df.copy()
    if {'stays_in_weekend_nights','stays_in_week_nights'}.issubset(out.columns):
        out['total_nights'] = pd.to_numeric(out['stays_in_weekend_nights'], errors='coerce') + pd.to_numeric(out['stays_in_week_nights'], errors='coerce')
    if {'adults','children','babies'}.issubset(out.columns):
        out['total_guests'] = sum(pd.to_numeric(out[c], errors='coerce').fillna(0) for c in ['adults','children','babies'])
    return out

def split_features_target(df):
    df = engineer_features(df).drop(columns=[TARGET] + LEAKAGE_COLUMNS, errors='ignore')
    return df

def build_preprocessor(X):
    numeric = X.select_dtypes(include='number').columns.tolist()
    categorical = X.select_dtypes(exclude='number').columns.tolist()
    num_pipe = Pipeline([('imputer', SimpleImputer(strategy='median')), ('scaler', StandardScaler())])
    cat_pipe = Pipeline([('imputer', SimpleImputer(strategy='most_frequent')), ('encoder', OneHotEncoder(handle_unknown='ignore', sparse_output=True))])
    return ColumnTransformer([('numeric', num_pipe, numeric), ('categorical', cat_pipe, categorical)], remainder='drop'), numeric, categorical

def get_preprocessing_report(df):
    X = split_features_target(df)
    numeric = X.select_dtypes(include='number').columns.tolist(); categorical = X.select_dtypes(exclude='number').columns.tolist()
    return {'rows':len(df),'input_columns':len(df.columns),'feature_columns':len(X.columns),'numeric_columns':numeric,'categorical_columns':categorical,'missing_by_column':df.isna().sum().sort_values(ascending=False).head(15).to_dict(),'excluded_columns':[c for c in LEAKAGE_COLUMNS if c in df.columns],'steps':['Drop reservation_status and reservation_status_date to prevent target leakage','Create total_nights and total_guests where source fields exist','Numeric: median imputation then StandardScaler','Categorical: most-frequent imputation then OneHotEncoder(handle_unknown=ignore)','Fit preprocessing only on the training split']}
