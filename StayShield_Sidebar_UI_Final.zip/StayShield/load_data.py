"""Dataset loading and validation."""
import pandas as pd
from config import DATA_PATH, TARGET, LEAKAGE_COLUMNS

EXPECTED_ROWS = 119390

def get_data_path(): return str(DATA_PATH)

def load_raw(path=None):
    path = path or DATA_PATH
    if not __import__('pathlib').Path(path).exists():
        raise FileNotFoundError(f"Dataset not found: {path}. Place hotel_bookings.csv in the StayShield project root.")
    df = pd.read_csv(path)
    if TARGET not in df.columns: raise ValueError(f"Dataset must contain target column '{TARGET}'.")
    return df

def load_clean(path=None):
    df = load_raw(path).copy()
    df = df.drop(columns=[c for c in LEAKAGE_COLUMNS if c in df.columns], errors='ignore')
    df[TARGET] = pd.to_numeric(df[TARGET], errors='raise').astype(int)
    if not set(df[TARGET].unique()).issubset({0,1}): raise ValueError("is_canceled must contain only 0 and 1.")
    return df

def get_dataset_summary(df=None):
    df = df if df is not None else load_raw()
    return {"rows": len(df), "columns": len(df.columns), "missing_cells": int(df.isna().sum().sum()),
            "target_counts": {str(k): int(v) for k,v in df[TARGET].value_counts().sort_index().items()},
            "numeric_columns": df.select_dtypes(include='number').columns.tolist(),
            "categorical_columns": df.select_dtypes(exclude='number').columns.tolist(),
            "leakage_columns_excluded": [c for c in LEAKAGE_COLUMNS if c in df.columns]}
