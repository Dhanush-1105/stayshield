"""IQR outlier summaries and optional clipping for numeric booking features."""
import pandas as pd
import numpy as np

def get_iqr_params(df, col, k=1.5):
    s=pd.to_numeric(df[col],errors='coerce').dropna(); q1=float(s.quantile(.25)); q3=float(s.quantile(.75)); iqr=q3-q1
    lo=q1-k*iqr; hi=q3+k*iqr
    return {'column':col,'q1':q1,'median':float(s.median()),'q3':q3,'iqr':iqr,'lower_fence':lo,'upper_fence':hi,'outlier_count':int(((s<lo)|(s>hi)).sum())}
def calculate_all_outliers(df): return {c:get_iqr_params(df,c) for c in df.select_dtypes(include='number').columns if c!='is_canceled'}
def apply_outlier_treatment(df,col,treatment='keep'):
    out=df.copy(); p=get_iqr_params(out,col)
    if treatment=='clip': out[col]=pd.to_numeric(out[col],errors='coerce').clip(p['lower_fence'],p['upper_fence'])
    elif treatment!='keep': raise ValueError('treatment must be keep or clip')
    return out,p

def generate_outlier_plots(df): return calculate_all_outliers(df)
