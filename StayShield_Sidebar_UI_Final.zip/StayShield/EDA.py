"""Booking-domain EDA, charts, findings and IQR summaries."""
import io, base64
import numpy as np, pandas as pd, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from config import TARGET

def _img(fig):
    b=io.BytesIO(); fig.savefig(b,format='png',dpi=90,bbox_inches='tight'); plt.close(fig); return base64.b64encode(b.getvalue()).decode()
def run_full_eda(df):
    charts=[]
    for col,title,kind in [('is_canceled','Booking Cancellation Distribution','bar'),('lead_time','Booking Lead Time Distribution','hist'),('adr','Average Daily Rate Distribution','hist'),('hotel','Bookings by Hotel Type','bar'),('market_segment','Bookings by Market Segment','bar'),('arrival_date_month','Bookings by Arrival Month','bar')]:
        if col not in df: continue
        fig,ax=plt.subplots(figsize=(7,3.3)); s=df[col].dropna()
        if kind=='hist': ax.hist(pd.to_numeric(s,errors='coerce').dropna(),bins=30)
        else:
            counts=s.value_counts().head(15)
            ax.bar(counts.index.astype(str),counts.values); ax.tick_params(axis='x',rotation=35)
        ax.set_title(title); ax.grid(axis='y',alpha=.2)
        charts.append({'id':col,'title':title,'what_it_shows':f'Distribution of {col} values in the supplied booking records.','image':_img(fig),'conclusion':f'{len(s):,} non-missing records are represented; most common value is {str(s.mode().iloc[0]) if len(s.mode()) else "unavailable"}.'})
    return charts

def generate_key_findings(df):
    cancel=float(pd.to_numeric(df[TARGET]).mean()*100) if TARGET in df else 0
    findings=[f"{cancel:.1f}% of records are labeled canceled (is_canceled=1).",f"Dataset contains {len(df):,} bookings and {len(df.columns)} columns.",f"{int(df.isna().sum().sum()):,} cells are missing and are handled within the training pipeline.","reservation_status and reservation_status_date are excluded from model features to prevent target leakage."]
    if 'hotel' in df: findings.append('Hotel mix: '+', '.join(f'{k}: {v:,}' for k,v in df['hotel'].value_counts().head(4).items()))
    return findings

def get_outlier_analysis(df):
    from outlier_treatment import calculate_all_outliers
    return calculate_all_outliers(df)
