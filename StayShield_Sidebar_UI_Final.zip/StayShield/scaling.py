"""Numeric scaling utilities: StandardScaler and MinMaxScaler."""
import pandas as pd
from sklearn.preprocessing import MinMaxScaler, StandardScaler

def get_scaling_stats(df, features=None):
    features = features or df.select_dtypes(include='number').columns.tolist(); x=df[features].apply(pd.to_numeric,errors='coerce').fillna(df[features].median())
    return {'features':features,'standard_mean':StandardScaler().fit(x).mean_.tolist(),'standard_scale':StandardScaler().fit(x).scale_.tolist(),'min':MinMaxScaler().fit(x).data_min_.tolist(),'max':MinMaxScaler().fit(x).data_max_.tolist()}

def apply_scaler(df, method='standard', features=None):
    out=df.copy(); features=features or out.select_dtypes(include='number').columns.tolist(); x=out[features].apply(pd.to_numeric,errors='coerce').fillna(out[features].median())
    scaler={'standard':StandardScaler(),'minmax':MinMaxScaler(),'none':None}.get(method)
    if method not in {'standard','minmax','none'}: raise ValueError('method must be standard, minmax, or none')
    if scaler is not None: out.loc[:,features]=scaler.fit_transform(x)
    return out, scaler
