/**
 * StayShield — Client-side Interactions
 * Manages UI transitions, tab selections, choice card active states,
 * and dynamic split slider value updates.
 */

document.addEventListener("DOMContentLoaded", () => {
    // 1. Preprocessing Tab Navigation
    const tabs = ["missing", "outliers", "encoding", "scaling", "split"];
    const subNavItems = document.querySelectorAll(".sub-nav-item");
    const panels = document.querySelectorAll(".pre-panel");
    const pipelineSteps = document.querySelectorAll(".pipeline .step");
    const activeTabInput = document.getElementById("active_tab_input");

    function switchTab(tabId) {
        if (!tabs.includes(tabId)) return;

        // Update active sub-nav item
        subNavItems.forEach(item => {
            if (item.getAttribute("data-tab") === tabId) {
                item.classList.add("active");
            } else {
                item.classList.remove("active");
            }
        });

        // Update active panel
        panels.forEach(panel => {
            if (panel.id === `panel-${tabId}`) {
                panel.classList.add("active");
            } else {
                panel.classList.remove("active");
            }
        });

        // Update visual pipeline steps
        pipelineSteps.forEach(step => {
            if (step.getAttribute("data-step") === tabId) {
                step.classList.add("active");
            } else {
                step.classList.remove("active");
            }
        });

        // Keep track of active tab in form submissions
        if (activeTabInput) {
            activeTabInput.value = tabId;
        }
        
        // Update URL hash/query without page reload
        const newUrl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?tab=' + tabId;
        window.history.replaceState({ path: newUrl }, '', newUrl);
    }

    // Bind click events to sub-nav items
    subNavItems.forEach(item => {
        item.addEventListener("click", () => {
            const tabId = item.getAttribute("data-tab");
            // If we are not on the preprocessing page, redirect to it with query param
            if (!document.getElementById("preprocessing-container")) {
                window.location.href = "/preprocessing?tab=" + tabId;
            } else {
                switchTab(tabId);
            }
        });
    });

    // Check URL query parameters to load active tab on preprocessing page
    if (document.getElementById("preprocessing-container")) {
        const urlParams = new URLSearchParams(window.location.search);
        const urlTab = urlParams.get("tab");
        if (urlTab && tabs.includes(urlTab)) {
            switchTab(urlTab);
        } else {
            // Default to missing values tab
            switchTab("missing");
        }
    }

    // 2. Choice Cards (Custom radio-button selection wrappers)
    const choiceCards = document.querySelectorAll(".choice-card");
    choiceCards.forEach(card => {
        card.addEventListener("click", (e) => {
            const radio = card.querySelector('input[type="radio"]');
            if (radio && e.target !== radio) {
                radio.checked = true;
                // Trigger change event manually
                const event = new Event('change', { bubbles: true });
                radio.dispatchEvent(event);
            }
            
            // Highlight selected card within its group
            const name = radio.getAttribute("name");
            document.querySelectorAll(`input[name="${name}"]`).forEach(r => {
                const parentCard = r.closest(".choice-card");
                if (parentCard) {
                    if (r.checked) {
                        parentCard.classList.add("selected");
                    } else {
                        parentCard.classList.remove("selected");
                    }
                }
            });
        });
    });

    // Initialize choice card selection classes on load
    document.querySelectorAll('input[type="radio"]:checked').forEach(radio => {
        const parentCard = radio.closest(".choice-card");
        if (parentCard) {
            parentCard.classList.add("selected");
        }
    });

    // 3. Train-Test Split Slider Update
    const testSizeSlider = document.getElementById("test_size");
    const testSizeValue = document.getElementById("test_size_val");
    if (testSizeSlider && testSizeValue) {
        testSizeSlider.addEventListener("input", () => {
            const val = parseFloat(testSizeSlider.value);
            testSizeValue.textContent = Math.round(val * 100) + "%";
        });
    }
});
