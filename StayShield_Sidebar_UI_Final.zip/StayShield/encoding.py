"""Categorical feature inspection and encoding utilities."""
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, OrdinalEncoder

def detect_categorical_columns(df): return df.select_dtypes(include=['object','category','string']).columns.tolist()
def apply_encoding(df, method='onehot'):
    cols=detect_categorical_columns(df); out=df.copy()
    if not cols or method=='none': return out, None
    if method=='onehot': return pd.get_dummies(out, columns=cols, dummy_na=False), 'onehot'
    if method=='ordinal':
        enc=OrdinalEncoder(handle_unknown='use_encoded_value',unknown_value=-1); out[cols]=enc.fit_transform(out[cols].fillna('Missing').astype(str)); return out,enc
    raise ValueError('method must be none, onehot, or ordinal')
