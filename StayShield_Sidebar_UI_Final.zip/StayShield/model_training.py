"""Train and persist all supervised StayShield models."""
import json, time
from pathlib import Path
import joblib, numpy as np, pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.base import clone
from sklearn.linear_model import LogisticRegression, LinearRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier, GradientBoostingClassifier, BaggingClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, classification_report, mean_absolute_error, mean_squared_error, r2_score, roc_curve
from config import ARTIFACT_DIR, CHART_DIR, RANDOM_STATE, TARGET
from preprocessing import engineer_features, build_preprocessor
from load_data import load_raw

MODELS = {
 'Logistic Regression': LogisticRegression(max_iter=600, class_weight='balanced', random_state=RANDOM_STATE),
 'Decision Tree': DecisionTreeClassifier(max_depth=12, min_samples_leaf=5, class_weight='balanced', random_state=RANDOM_STATE),
 'Random Forest': RandomForestClassifier(n_estimators=100, max_depth=18, min_samples_leaf=3, class_weight='balanced_subsample', n_jobs=-1, random_state=RANDOM_STATE),
 'AdaBoost': AdaBoostClassifier(n_estimators=60, learning_rate=.7, random_state=RANDOM_STATE),
 'Gradient Boosting': GradientBoostingClassifier(n_estimators=60, max_depth=3, random_state=RANDOM_STATE),
 'Bagging Classifier': BaggingClassifier(n_estimators=30, max_samples=0.8, n_jobs=-1, random_state=RANDOM_STATE),
}

def _save_evaluation_charts(rows, matrices, reports, y_test, probabilities, regression_values=None):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from sklearn.metrics import ConfusionMatrixDisplay
    CHART_DIR.mkdir(parents=True, exist_ok=True)
    # Clear stale charts so the page only displays results from the latest run.
    for old in CHART_DIR.glob('*.png'):
        old.unlink()
    classifier_rows = [r for r in rows if r.get('accuracy') is not None]
    for metric in ('accuracy', 'precision', 'recall', 'f1', 'roc_auc'):
        valid = [r for r in classifier_rows if r.get(metric) is not None]
        if not valid: continue
        fig, ax = plt.subplots(figsize=(9, 4.8))
        ax.bar([r['model'] for r in valid], [r[metric] for r in valid])
        ax.set_ylim(0, 1); ax.set_ylabel(metric.replace('_',' ').title()); ax.set_title(f'Model comparison: {metric.upper()}')
        ax.tick_params(axis='x', rotation=20); fig.tight_layout(); fig.savefig(CHART_DIR/f'{metric}_comparison.png', dpi=140); plt.close(fig)
    for name, cm in matrices.items():
        fig, ax = plt.subplots(figsize=(5, 4))
        ConfusionMatrixDisplay(np.asarray(cm), display_labels=['Kept (0)', 'Canceled (1)']).plot(ax=ax, colorbar=False)
        ax.set_title(f'{name} — Confusion Matrix'); fig.tight_layout()
        slug = ''.join(ch.lower() if ch.isalnum() else '_' for ch in name).strip('_')
        fig.savefig(CHART_DIR/f'confusion_{slug}.png', dpi=140); plt.close(fig)
    fig, ax = plt.subplots(figsize=(7, 5))
    for name, prob in probabilities.items():
        from sklearn.metrics import roc_curve, roc_auc_score
        fpr, tpr, _ = roc_curve(y_test, prob); ax.plot(fpr, tpr, label=f"{name} (AUC={roc_auc_score(y_test, prob):.3f})")
    ax.plot([0,1],[0,1], linestyle='--', linewidth=1); ax.set_xlabel('False Positive Rate'); ax.set_ylabel('True Positive Rate'); ax.set_title('ROC Curves'); ax.legend(fontsize=8); fig.tight_layout(); fig.savefig(CHART_DIR/'roc_curves.png', dpi=140); plt.close(fig)
    if regression_values is not None:
        actual, predicted = regression_values
        fig, ax = plt.subplots(figsize=(6,5)); ax.scatter(actual, predicted, s=8, alpha=.25)
        ax.set_xlabel('Actual cancellation label'); ax.set_ylabel('Linear Regression score'); ax.set_title('Linear Regression baseline: actual vs predicted'); fig.tight_layout(); fig.savefig(CHART_DIR/'linear_regression_actual_vs_predicted.png', dpi=140); plt.close(fig)

def train_models(df=None, sample_limit=30000):
    df = load_raw() if df is None else df.copy()
    df = engineer_features(df).drop(columns=['reservation_status','reservation_status_date'], errors='ignore')
    y = pd.to_numeric(df.pop(TARGET), errors='raise').astype(int); X=df
    if len(X)>sample_limit:
        X, _, y, _ = train_test_split(X,y,train_size=sample_limit,random_state=RANDOM_STATE,stratify=y)
    X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=.2,random_state=RANDOM_STATE,stratify=y)
    preprocessor,numeric,categorical=build_preprocessor(X_train)
    ARTIFACT_DIR.mkdir(parents=True,exist_ok=True)
    models={}; rows=[]; matrices={}; reports={}; probabilities={}
    for name, estimator in MODELS.items():
        pipe=Pipeline([('preprocessor',clone(preprocessor)),('model',estimator)])
        started=time.time(); pipe.fit(X_train,y_train); pred=pipe.predict(X_test); elapsed=round(time.time()-started,2)
        proba=pipe.predict_proba(X_test)[:,1] if hasattr(pipe,'predict_proba') else None
        if proba is not None: probabilities[name]=proba
        metrics={'model':name,'accuracy':round(accuracy_score(y_test,pred),4),'precision':round(precision_score(y_test,pred,zero_division=0),4),'recall':round(recall_score(y_test,pred,zero_division=0),4),'f1':round(f1_score(y_test,pred,zero_division=0),4),'roc_auc':round(roc_auc_score(y_test,proba),4) if proba is not None else None,'r2':None,'mae':None,'rmse':None,'train_seconds':elapsed}
        rows.append(metrics); matrices[name]=confusion_matrix(y_test,pred,labels=[0,1]).tolist(); reports[name]=classification_report(y_test,pred,labels=[0,1],target_names=['Kept','Canceled'],output_dict=True,zero_division=0); models[name]=pipe
    # Retained regression baseline: include regression-specific metrics, not misleading classifier metrics.
    lr=Pipeline([('preprocessor',clone(preprocessor)),('model',LinearRegression())]); lr.fit(X_train,y_train); lr_pred=np.clip(lr.predict(X_test),0,1); models['Linear Regression (baseline)']=lr
    rows.append({'model':'Linear Regression (baseline)','accuracy':None,'precision':None,'recall':None,'f1':None,'roc_auc':None,'r2':round(float(r2_score(y_test,lr_pred)),4),'mae':round(float(mean_absolute_error(y_test,lr_pred)),4),'rmse':round(float(mean_squared_error(y_test,lr_pred)**0.5),4),'train_seconds':None})
    _save_evaluation_charts(rows, matrices, reports, y_test, probabilities, (y_test.to_numpy(), lr_pred))
    payload={'models':models,'feature_columns':X.columns.tolist(),'metrics':rows,'confusion_matrices':matrices,'reports':reports,'numeric_columns':numeric,'categorical_columns':categorical,'sample_rows':len(X),'train_rows':len(X_train),'test_rows':len(X_test),'target_counts':y.value_counts().sort_index().to_dict(),'chart_files':[p.name for p in CHART_DIR.glob('*.png')]}
    joblib.dump(payload,ARTIFACT_DIR/'models.joblib',compress=3)
    pd.DataFrame(rows).to_csv(ARTIFACT_DIR/'model_metrics.csv',index=False)
    return rows

if __name__=='__main__':
    result=train_models()
    print(pd.DataFrame(result).to_string(index=False))
