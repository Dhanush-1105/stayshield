"""StayShield Flask application. Start with: python app.py"""
from flask import Flask, render_template, request, redirect, url_for, flash
from pathlib import Path
import joblib, pandas as pd
from config import ARTIFACT_DIR, TARGET, LEAKAGE_COLUMNS
from load_data import load_raw, get_dataset_summary
from preprocessing import get_preprocessing_report, engineer_features
from EDA import run_full_eda, generate_key_findings
from outlier_treatment import calculate_all_outliers
from model_training import train_models
from unsupervised import get_unsupervised_suite, run_kmeans, run_hierarchical, run_dbscan, run_pca_view, run_isolation_forest, get_unsupervised_comparison_table

app=Flask(__name__); app.secret_key='stayshield-local-app-key'
PAGES={
 'dataset_overview':('Dataset Overview','/dataset-overview'), 'eda':('Exploratory Data Analysis','/eda'),
 'preprocessing':('Preprocessing','/preprocessing'), 'linear_regression':('Linear Regression Baseline','/linear-regression'),
 'logistic_regression':('Logistic Regression','/logistic-regression'), 'tree_models':('Tree & Ensemble Models','/tree-models'),
 'unsupervised':('Unsupervised Learning','/unsupervised'), 'evaluation':('Model Evaluation','/evaluation'), 'train':('Train Models','/train')}

def get_df(): return load_raw()
def get_artifacts():
    p=ARTIFACT_DIR/'models.joblib'
    return joblib.load(p) if p.exists() else None

def render_page(key, **kwargs):
    page_title, _=PAGES[key]
    return render_template(f'{key}.html', page_title=page_title, page_key=key, nav_pages=PAGES, **kwargs)

@app.route('/')
@app.route('/dataset-overview')
def dataset_overview():
    try:
        df=get_df(); return render_page('dataset_overview', summary=get_dataset_summary(df), findings=generate_key_findings(df), preview=df.head(10).to_html(index=False,classes='data-table',border=0))
    except Exception as e: return render_page('dataset_overview', error=str(e), summary=None, findings=[], preview='')
@app.route('/eda')
def eda():
    try: df=get_df(); return render_page('eda', charts=run_full_eda(df), findings=generate_key_findings(df))
    except Exception as e: return render_page('eda', error=str(e), charts=[], findings=[])
@app.route('/preprocessing')
def preprocessing():
    try: return render_page('preprocessing', report=get_preprocessing_report(get_df()))
    except Exception as e: return render_page('preprocessing', error=str(e), report=None)
@app.route('/linear-regression',methods=['GET','POST'])
def linear_regression():
    try:
        art=get_artifacts(); pred=None
        if request.method=='POST':
            if not art: flash('Train models first.','warning')
            else: pred=float(art['models']['Linear Regression (baseline)'].predict(_form_frame(request.form,art))[0]); pred=max(0,min(1,pred))
        return render_page('linear_regression', artifacts=art, prediction=pred, fields=_form_fields())
    except Exception as e: return render_page('linear_regression', error=str(e),artifacts=None,prediction=None,fields=[])
@app.route('/logistic-regression',methods=['GET','POST'])
def logistic_regression():
    try:
        art=get_artifacts(); result=None
        if request.method=='POST':
            if not art: flash('Train models first.','warning')
            else:
                x=_form_frame(request.form,art); model=art['models']['Logistic Regression']; cls=int(model.predict(x)[0]); prob=float(model.predict_proba(x)[0,1]); result={'label':'Likely to CANCEL' if cls else 'Likely to be KEPT','class':cls,'probability':prob}
        return render_page('logistic_regression', artifacts=art, prediction=result, fields=_form_fields())
    except Exception as e: return render_page('logistic_regression', error=str(e),artifacts=None,prediction=None,fields=_form_fields())
@app.route('/tree-models',methods=['GET','POST'])
def tree_models():
    try: return render_page('tree_models', artifacts=get_artifacts())
    except Exception as e: return render_page('tree_models',error=str(e),artifacts=None)
@app.route('/unsupervised',methods=['GET','POST'])
def unsupervised_view():
    try:
        df=get_df(); suite=get_unsupervised_suite(df); tab=request.form.get('tab','kmeans'); k=int(request.form.get('kmeans_k',3)); km=run_kmeans(suite,k); hier=run_hierarchical(suite); db=run_dbscan(suite); pca=run_pca_view(suite); anomaly=run_isolation_forest(suite)
        return render_page('unsupervised', active_tab=tab, km_res=km,hier_res=hier,db_res=db,pca_res=pca,anomaly_res=anomaly,comparison=get_unsupervised_comparison_table(km,hier,db,pca,anomaly))
    except Exception as e: return render_page('unsupervised',error=str(e),active_tab='kmeans',km_res=None,hier_res=None,db_res=None,pca_res=None,anomaly_res=None,comparison=[])
@app.route('/kmeans')
def kmeans_alias(): return redirect(url_for('unsupervised_view'))
@app.route('/hierarchical')
def hierarchical_alias(): return redirect(url_for('unsupervised_view'))
@app.route('/dbscan')
def dbscan_alias(): return redirect(url_for('unsupervised_view'))
@app.route('/pca')
def pca_alias(): return redirect(url_for('unsupervised_view'))
@app.route('/anomaly-detection')
@app.route('/isolation-forest')
def anomaly_alias(): return redirect(url_for('unsupervised_view'))
@app.route('/data-loading')
def data_loading_redirect(): return redirect(url_for('dataset_overview'))
@app.route('/evaluation',methods=['GET','POST'])
def evaluation_view():
    try: return render_page('evaluation',artifacts=get_artifacts())
    except Exception as e: return render_page('evaluation',error=str(e),artifacts=None)
@app.route('/model-evaluation')
@app.route('/module-5')
@app.route('/calibration')
def evaluation_aliases(): return redirect(url_for('evaluation_view'))
@app.route('/train',methods=['GET','POST'])
def train_view():
    result=None; error=None
    if request.method=='POST':
        try: result=train_models(get_df())
        except Exception as e: error=str(e)
    return render_page('train', result=result,error=error,artifacts=get_artifacts())

def _form_fields():
    try:
        df=get_df(); features=df.drop(columns=[TARGET]+LEAKAGE_COLUMNS,errors='ignore'); fields=[]
        for c in features.columns:
            s=features[c]
            if pd.api.types.is_numeric_dtype(s): fields.append({'name':c,'type':'number','value':float(s.median()) if s.notna().any() else 0,'options':[]})
            else:
                vals=s.dropna().astype(str).value_counts().head(12).index.tolist(); fields.append({'name':c,'type':'select','value':vals[0] if vals else '', 'options':vals})
        # Compact form: include all fields, arranged responsively by template.
        return fields
    except Exception: return []
def _form_frame(form,art):
    df=get_df(); features=df.drop(columns=[TARGET]+LEAKAGE_COLUMNS,errors='ignore'); row={}
    for c in features.columns:
        raw=form.get(c)
        if raw is None or raw=='': row[c]=features[c].median() if pd.api.types.is_numeric_dtype(features[c]) else (features[c].mode().iloc[0] if not features[c].mode().empty else 'Unknown')
        elif pd.api.types.is_numeric_dtype(features[c]): row[c]=float(raw)
        else: row[c]=raw
    frame=pd.DataFrame([row]); frame=engineer_features(frame)
    return frame[art['feature_columns']]

if __name__=='__main__':
    app.run(host='127.0.0.1',port=5000,debug=False)
