"""Decision Tree, Random Forest, AdaBoost, and Gradient Boosting model access."""
from model_training import train_models
from config import ARTIFACT_DIR
import joblib

def get_tree_models_suite(df=None):
    if not (ARTIFACT_DIR/'models.joblib').exists(): train_models(df)
    return joblib.load(ARTIFACT_DIR/'models.joblib')['models']
